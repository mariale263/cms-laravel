<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper container">
  <?php if(session()->get('message')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('message')); ?>  
    </div><br />
  <?php endif; ?>
  <div class="card-header">
    Listado
  </div>

  <div class="table-responsive">
    <table class="table table-striped ">
            <thead>
                <tr>
                <td>ID</td>
                <td>Nombre</td>
                <td>Correo</td>
                <td>Mensaje</td>
                <td colspan="2">Action</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contacto->id); ?></td>
                    <td><?php echo e($contacto->name); ?></td>
                    <td><?php echo e($contacto->email); ?></td>
                    <td><?php echo e($contacto->message); ?></td>
                    <td><a href="<?php echo e(route('contactos.edit', $contacto->id)); ?>" class="btn btn-primary fa fa-edit"></a></td>
                    <td>
                        <form action="<?php echo e(route('contactos.destroy', $contacto->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger fa fa-trash" type="submit"></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
  </div>
    
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectosMaria\cms\resources\views/contacto/index.blade.php ENDPATH**/ ?>