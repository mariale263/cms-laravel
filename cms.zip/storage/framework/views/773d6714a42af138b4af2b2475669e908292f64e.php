<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper container">
  <div class="card-header">
    <h4>Actualizar</h4>
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('contactos.update', $contact->id)); ?>">
          <div class="form-group">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PATCH'); ?>
              <label for="name">Nombre:</label>
              <input type="text" class="form-control" name="name" value="<?php echo e($contact->name); ?>"/>
          </div>
          <div class="form-group">
              <label for="price">Email :</label>
              <input type="email" class="form-control" name="email" value="<?php echo e($contact->email); ?>"/>
          </div>
          <div class="form-group">
              <label for="quantity">Mensaje :</label>
              <input type="text" class="form-control" name="message" value="<?php echo e($contact->message); ?>"/>
          </div>
          <button type="submit" class="btn btn-primary">Actualizar</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectosMaria\cms\resources\views/contacto/edit.blade.php ENDPATH**/ ?>